#include<bits/stdc++.h>
using namespace std;
#define run1 int t; cin >> t;
#define run2 int t; cin >> t; cin.ignore();
typedef long long ll;
int main(){
	freopen("test1.inp", "r", stdin);
	freopen("test1.out", "w", stdout);
	int n; cin >> n;
	cout << (ll) n * 18 << endl;
	return 0;
}
